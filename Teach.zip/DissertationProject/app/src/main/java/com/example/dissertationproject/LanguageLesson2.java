package com.example.dissertationproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class LanguageLesson2 extends AppCompatActivity {

    //declaring views
    private EditText similesEdtxt;
    private EditText similesEdtxt2;
    private TextView similesTxtv;
    private TextView similesTxtv2;
    private TextView similesTxtv3;
    private EditText similesEdtxt3;
    private TextView similesTxtv4;
    private EditText similesEdtxt4;
    private TextView similesTxtv5;
    private EditText similesEdtxt5;
    private TextView similesTxtv6;
    private EditText similesEdtxt6;
    private TextView similesTxtv7;
    private TextView similesTxtv8;
    private TextView similesTxtv9;
    private EditText similesEdtxt7;
    private TextView similesTxtv10;
    private TextView similesTxtv11;
    private TextView similesTxtv12;
    private EditText similesEdtxt8;
    private TextView similesTxtv13;
    private TextView similesTxtv14;
    private TextView similesTxtv15;
    private EditText similesEdtxt9;
    private EditText similesEdtxt10;
    private EditText similesEdtxt11;
    private EditText similesEdtxt12;
    private EditText similesEdtxt13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_lesson2);

        //initialising views
        similesEdtxt = findViewById(R.id.studentSimiles);
        similesTxtv = findViewById(R.id.p3Similes);
        similesEdtxt2 = findViewById(R.id.dateOfSimilesLesson);
        similesTxtv2 = findViewById(R.id.similes);
        similesTxtv3 = findViewById(R.id.generatedEAndOSimiles);
        similesEdtxt3 = findViewById(R.id.enterEAndOChangesSimiles);
        similesTxtv4 = findViewById(R.id.generatedLISimiles);
        similesEdtxt4 = findViewById(R.id.enterLIChangesSimiles);
        similesTxtv5 = findViewById(R.id.generatedSuccessCriteriaSimiles);
        similesEdtxt5 = findViewById(R.id.enterSuccessCriteriaChangesSimiles);
        similesTxtv6 = findViewById(R.id.generatedAssessmentLearningSimiles);
        similesEdtxt6 = findViewById(R.id.enterAssessLearningChangesSimiles);
        similesTxtv7 = findViewById(R.id.activitiesOpenSimiles);
        similesTxtv8 = findViewById(R.id.activitiesCoreSimiles);
        similesTxtv9 = findViewById(R.id.activitiesCloseSimiles);
        similesEdtxt7 = findViewById(R.id.enterActivitiesChangesSimiles);
        similesTxtv10 = findViewById(R.id.pupilOpenSimiles);
        similesTxtv11 = findViewById(R.id.pupilCoreSimiles);
        similesTxtv12 = findViewById(R.id.pupilCloseSimiles);
        similesEdtxt8 = findViewById(R.id.enterPupilChangesSimiles);
        similesTxtv13 = findViewById(R.id.resourcesOpenSimiles);
        similesTxtv14 = findViewById(R.id.resourcesCoreSimiles);
        similesTxtv15 = findViewById(R.id.resourcesCloseSimiles);
        similesEdtxt9 = findViewById(R.id.enterResourcesChangesSimiles);
        similesEdtxt10 = findViewById(R.id.evidenceLearningSimiles);
        similesEdtxt11 = findViewById(R.id.areasDevelopSimiles);
        similesEdtxt12 = findViewById(R.id.evidencePracticeSimiles);
        similesEdtxt13 = findViewById(R.id.practiceAreasDevelopSimiles);
        ActivityCompat.requestPermissions(LanguageLesson2.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createSimilePDF (View view){

        //create pdf object
        PdfDocument similesPdfDocument = new PdfDocument();
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        PdfDocument.Page similesPage = similesPdfDocument.startPage(myPageInfo);

        //add to pdf object
        Paint mypaint = new Paint();
        String similesString = "Student: "+ similesEdtxt.getText().toString();
        int x=10, y=25;
        similesPage.getCanvas().drawText(similesString, x, y, mypaint);

        String txtString = "Class: " + similesTxtv.getText().toString();
        int a=10, b=35;
        similesPage.getCanvas().drawText(txtString, a, b, mypaint);

        String similesString2 = "Date: " + similesEdtxt2.getText().toString();
        int x2=10, y2=45;
        similesPage.getCanvas().drawText(similesString2, x2, y2, mypaint);

        String txtString2 = "Lesson Title: " + similesTxtv2.getText().toString();
        int a2=10, b2=55;
        similesPage.getCanvas().drawText(txtString2, a2, b2, mypaint);

        String txtString3 = "Experiences and Outcomes: " + similesTxtv3.getText().toString();
        int a3=10, b3=105;
        similesPage.getCanvas().drawText(txtString3, a3, b3, mypaint);

        String similesString3 = "Any Changes to Experiences and Outcomes: " + similesEdtxt3.getText().toString();
        int x3=10, y3=200;
        similesPage.getCanvas().drawText(similesString3, x3, y3, mypaint);

        String txtString4 = "Learning Intentions: " + similesTxtv4.getText().toString();
        int a4=10, b4=250;
        similesPage.getCanvas().drawText(txtString4, a4, b4, mypaint);

        String similesString4 ="Any Changes to Learning Intentions: " + similesEdtxt4.getText().toString();
        int x4=10, y4= 350;
        similesPage.getCanvas().drawText(similesString4, x4, y4, mypaint);

        String txtString5 = "Success Criteria: " + similesTxtv5.getText().toString();
        int a5=10, b5=400;
        similesPage.getCanvas().drawText(txtString5, a5, b5, mypaint);

        String similesString5 = "Any Changes to Success Criteria: " + similesEdtxt5.getText().toString();
        int x5=10, y5=500;
        similesPage.getCanvas().drawText(similesString5, x5, y5, mypaint);

        String txtString6 = "Assessment of Children's Learning: " + similesTxtv6.getText().toString();
        int a6=10, b6=550;
        similesPage.getCanvas().drawText(txtString6, a6, b6, mypaint);

        String similesString6 = "Any Changes to Children's Learning: " + similesEdtxt6.getText().toString();
        int x6=10, y6=650;
        similesPage.getCanvas().drawText(similesString6, x6, y6, mypaint);

        String txtString7 = " Activities - Opening Phase: " + similesTxtv7.getText().toString();
        int a7=10, b7=700;
        similesPage.getCanvas().drawText(txtString7, a7, b7, mypaint);

        String txtString8 = " Activities - Teaching and Core Learning Phase: " + similesTxtv8.getText().toString();
        int a8=10, b8=800;
        similesPage.getCanvas().drawText(txtString8, a8, b8, mypaint);

        String txtString9 = " Activities - Opening Phase: " + similesTxtv9.getText().toString();
        int a9=10, b9=900;
        similesPage.getCanvas().drawText(txtString9, a9, b9, mypaint);

        String similesString7 = "Any Changes to the Activities: " + similesEdtxt7.getText().toString();
        int x7=10, y7=1000;
        similesPage.getCanvas().drawText(similesString7, x7, y7, mypaint);

        String txtString10 = " Pupil Tasks - Opening Phase: " + similesTxtv10.getText().toString();
        int a10=10, b10=1050;
        similesPage.getCanvas().drawText(txtString10, a10, b10, mypaint);

        String txtString11 = " Pupil Tasks - Teaching and Core Learning Phase: " + similesTxtv11.getText().toString();
        int a11=10, b11=1250;
        similesPage.getCanvas().drawText(txtString11, a11, b11, mypaint);

        String txtString12 = " Pupil Tasks - Opening Phase: " + similesTxtv12.getText().toString();
        int a12=10, b12=1450;
        similesPage.getCanvas().drawText(txtString12, a12, b12, mypaint);

        String similesString8 = "Any Changes to the Pupil Tasks: " + similesEdtxt8.getText().toString();
        int x8=10, y8=1650;
        similesPage.getCanvas().drawText(similesString8, x8, y8, mypaint);

        String txtString13 = " Resources - Opening Phase: " + similesTxtv13.getText().toString();
        int a13=10, b13=1750;
        similesPage.getCanvas().drawText(txtString13, a13, b13, mypaint);

        String txtString14 = " Resources - Teaching and Core Learning Phase: " + similesTxtv14.getText().toString();
        int a14=10, b14=1950;
        similesPage.getCanvas().drawText(txtString14, a14, b14, mypaint);

        String txtString15 = " Resources - Opening Phase: " + similesTxtv15.getText().toString();
        int a15=10, b15=2250;
        similesPage.getCanvas().drawText(txtString15, a15, b15, mypaint);

        String similesString9 = "Any Changes to the Resources: " + similesEdtxt9.getText().toString();
        int x9=10, y9=2450;
        similesPage.getCanvas().drawText(similesString9, x9, y9, mypaint);

        String similesString10 = "Evidence of Learning: " + similesEdtxt10.getText().toString();
        int x10=10, y10=2650;
        similesPage.getCanvas().drawText(similesString10, x10, y10, mypaint);

        String similesString11 = "Areas for Development: " + similesEdtxt11.getText().toString();
        int x11=10, y11=2850;
        similesPage.getCanvas().drawText(similesString11, x11, y11, mypaint);

        String similesString12 = "Evidence of Effective Practice: " + similesEdtxt12.getText().toString();
        int x12=10, y12=3050;
        similesPage.getCanvas().drawText(similesString12, x12, y12, mypaint);

        String similesString13 = "Areas for Development: " + similesEdtxt13.getText().toString();
        int x13=10, y13=3250;
        similesPage.getCanvas().drawText(similesString13, x13, y13, mypaint);

        //finish adding to pdf
        similesPdfDocument.finishPage(similesPage);

        //create path to access pdf
        String myFilePath = Environment.getExternalStorageDirectory().getPath() + "/SimilesLessonPlan.pdf";
        File myFile = new File(myFilePath);

        try {
            similesPdfDocument.writeTo(new FileOutputStream(myFile));
        }
        catch (Exception e){

            e.printStackTrace();
            similesEdtxt.setText("ERROR");

        }

        //close pdf object
        similesPdfDocument.close();

        //show message that pdf is saved
        Toast.makeText(this, myFilePath + ".pdf\nis saved to\n", Toast.LENGTH_SHORT).show();

    }


}