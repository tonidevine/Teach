package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class TechActivity extends AppCompatActivity {

    private static final String TAG = "TechActivity";

    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech);
        ListView list = (ListView) findViewById(R.id.techList);
        EditText techFilter = (EditText) findViewById(R.id.searchFilterTech);
        Log.d(TAG, "onCreate: Started.");

        ArrayList<String> techLessons = new ArrayList<>();
        //add items to list of tech lessons
        techLessons.add("Lesson 1");
        techLessons.add("Lesson 2");
        techLessons.add("Lesson 3");
        techLessons.add("Lesson 4");
        techLessons.add("Lesson 5");
        techLessons.add("Lesson 6");

        adapter = new ArrayAdapter(this, R.layout.list_item_layout, techLessons);
        list.setAdapter(adapter);


        //filter listview
        techFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (TechActivity.this).adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
