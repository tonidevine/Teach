package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class LanguageActivity extends AppCompatActivity {

    private static final String TAG = "LanguageActivity";

    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        ListView list = (ListView) findViewById(R.id.languageList);
        EditText languageFilter = (EditText) findViewById(R.id.searchFilterLanguage);
        Log.d(TAG, "onCreate: Started.");

        ArrayList<String> languageLessons = new ArrayList<>();
        //add items to list of language lessons
        languageLessons.add("Comprehension Introduction - P7");
        languageLessons.add("Similes - P3");
        languageLessons.add("Lesson 3");
        languageLessons.add("Lesson 4");
        languageLessons.add("Lesson 5");
        languageLessons.add("Lesson 6");

         adapter = new ArrayAdapter(this, R.layout.list_item_layout, languageLessons);
        list.setAdapter(adapter);

        //clicking items on list
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //what to do if item is clicked that matches string
                if (((String)adapter.getItem(position)==("Comprehension Introduction - P7"))){
                    Intent myIntent = new Intent(view.getContext(),LanguageLesson.class);
                    startActivityForResult(myIntent,0);
                }

                //what to do if item is clicked that matches string
                if (((String)adapter.getItem(position)==("Similes - P3"))){
                    Intent myIntent = new Intent(view.getContext(),LanguageLesson2.class);
                    startActivityForResult(myIntent,0);
                }
            }
        });

        //filter listview
        languageFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (LanguageActivity.this).adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
