package com.example.dissertationproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.graphics.text.MeasuredText;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MathsLesson extends AppCompatActivity {

    //declaring views
    private EditText shapesEdtxt;
    private EditText shapesEdtxt2;
    private TextView shapesTxtv;
    private TextView shapesTxtv2;
    private TextView shapesTxtv3;
    private EditText shapesEdtxt3;
    private TextView shapesTxtv4;
    private EditText shapesEdtxt4;
    private TextView shapesTxtv5;
    private EditText shapesEdtxt5;
    private TextView shapesTxtv6;
    private EditText shapesEdtxt6;
    private TextView shapesTxtv7;
    private TextView shapesTxtv8;
    private TextView shapesTxtv9;
    private EditText shapesEdtxt7;
    private TextView shapesTxtv10;
    private TextView shapesTxtv11;
    private TextView shapesTxtv12;
    private EditText shapesEdtxt8;
    private TextView shapesTxtv13;
    private TextView shapesTxtv14;
    private TextView shapesTxtv15;
    private EditText shapesEdtxt9;
    private EditText shapesEdtxt10;
    private EditText shapesEdtxt11;
    private EditText shapesEdtxt12;
    private EditText shapesEdtxt13;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths_lesson);

        //initialising views
        shapesEdtxt = findViewById(R.id.studentShapes);
        shapesTxtv = findViewById(R.id.p2_3Shapes);
        shapesEdtxt2 = findViewById(R.id.dateOfShapesLesson);
        shapesTxtv2 = findViewById(R.id.exploringShapes);
        shapesTxtv3 = findViewById(R.id.generatedEAndOShapes);
        shapesEdtxt3 = findViewById(R.id.enterEAndOChangesShapes);
        shapesTxtv4 = findViewById(R.id.generatedLIShapes);
        shapesEdtxt4 = findViewById(R.id.enterLIChangesShapes);
        shapesTxtv5 = findViewById(R.id.generatedSuccessCriteriaShapes);
        shapesEdtxt5 = findViewById(R.id.enterSuccessCriteriaChangesShape);
        shapesTxtv6 = findViewById(R.id.generatedAssessmentLearningShapes);
        shapesEdtxt6 = findViewById(R.id.enterAssessLearningChangesShapes);
        shapesTxtv7 = findViewById(R.id.activitiesOpenShapes);
        shapesTxtv8 = findViewById(R.id.activitiesCoreShapes);
        shapesTxtv9 = findViewById(R.id.activitiesCloseShapes);
        shapesEdtxt7 = findViewById(R.id.enterActivitiesChangesShapes);
        shapesTxtv10 = findViewById(R.id.pupilOpenShapes);
        shapesTxtv11 = findViewById(R.id.pupilCoreShapes);
        shapesTxtv12 = findViewById(R.id.pupilCloseShapes);
        shapesEdtxt8 = findViewById(R.id.enterPupilChangesShapes);
        shapesTxtv13 = findViewById(R.id.resourcesOpenShapes);
        shapesTxtv14 = findViewById(R.id.resourcesCoreShapes);
        shapesTxtv15 = findViewById(R.id.resourcesCloseShapes);
        shapesEdtxt9 = findViewById(R.id.enterResourcesChangesShapes);
        shapesEdtxt10 = findViewById(R.id.evidenceLearningShapes);
        shapesEdtxt11 = findViewById(R.id.areasDevelopShapes);
        shapesEdtxt12 = findViewById(R.id.evidencePracticeShapes);
        shapesEdtxt13 = findViewById(R.id.practiceAreasDevelopShapes);
        ActivityCompat.requestPermissions(MathsLesson.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createShapesPDF (View view) {

        //create pdf object
        PdfDocument shapesPdfDocument = new PdfDocument();
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        PdfDocument.Page shapesPage = shapesPdfDocument.startPage(myPageInfo);


        //add to pdf object
        Paint mypaint = new Paint();
        String shapesString = "Student: "+ shapesEdtxt.getText().toString();
        int x=10, y=25;
        shapesPage.getCanvas().drawText(shapesString, x, y, mypaint);

        String txtString = "Class: " + shapesTxtv.getText().toString();
        int a=10, b=35;
        shapesPage.getCanvas().drawText(txtString, a, b, mypaint);

        String shapesString2 = "Date: " + shapesEdtxt2.getText().toString();
        int x2=10, y2=45;
        shapesPage.getCanvas().drawText(shapesString2, x2, y2, mypaint);

        String txtString2 = "Lesson Title: " + shapesTxtv2.getText().toString();
        int a2=10, b2=55;
        shapesPage.getCanvas().drawText(txtString2, a2, b2, mypaint);

        String txtString3 = "Experiences and Outcomes: " + shapesTxtv3.getText().toString();
        int a3=10, b3=105;
        shapesPage.getCanvas().drawText(txtString3, a3, b3, mypaint);

        String shapesString3 = "Any Changes to Experiences and Outcomes: " + shapesEdtxt3.getText().toString();
        int x3=10, y3=200;
        shapesPage.getCanvas().drawText(shapesString3, x3, y3, mypaint);

        String txtString4 = "Learning Intentions: " + shapesTxtv4.getText().toString();
        int a4=10, b4=250;
        shapesPage.getCanvas().drawText(txtString4, a4, b4, mypaint);

        String shapesString4 ="Any Changes to Learning Intentions: " + shapesEdtxt4.getText().toString();
        int x4=10, y4= 350;
        shapesPage.getCanvas().drawText(shapesString4, x4, y4, mypaint);

        String txtString5 = "Success Criteria: " + shapesTxtv5.getText().toString();
        int a5=10, b5=400;
        shapesPage.getCanvas().drawText(txtString5, a5, b5, mypaint);

        String shapesString5 = "Any Changes to Success Criteria: " + shapesEdtxt5.getText().toString();
        int x5=10, y5=500;
        shapesPage.getCanvas().drawText(shapesString5, x5, y5, mypaint);

        String txtString6 = "Assessment of Children's Learning: " + shapesTxtv6.getText().toString();
        int a6=10, b6=550;
        shapesPage.getCanvas().drawText(txtString6, a6, b6, mypaint);

        String shapesString6 = "Any Changes to Children's Learning: " + shapesEdtxt6.getText().toString();
        int x6=10, y6=650;
        shapesPage.getCanvas().drawText(shapesString6, x6, y6, mypaint);

        String txtString7 = " Activities - Opening Phase: " + shapesTxtv7.getText().toString();
        int a7=10, b7=700;
        shapesPage.getCanvas().drawText(txtString7, a7, b7, mypaint);

        String txtString8 = " Activities - Teaching and Core Learning Phase: " + shapesTxtv8.getText().toString();
        int a8=10, b8=800;
        shapesPage.getCanvas().drawText(txtString8, a8, b8, mypaint);

        String txtString9 = " Activities - Opening Phase: " + shapesTxtv9.getText().toString();
        int a9=10, b9=900;
        shapesPage.getCanvas().drawText(txtString9, a9, b9, mypaint);

        String shapesString7 = "Any Changes to the Activities: " + shapesEdtxt7.getText().toString();
        int x7=10, y7=1000;
        shapesPage.getCanvas().drawText(shapesString7, x7, y7, mypaint);

        String txtString10 = " Pupil Tasks - Opening Phase: " + shapesTxtv10.getText().toString();
        int a10=10, b10=1050;
        shapesPage.getCanvas().drawText(txtString10, a10, b10, mypaint);

        String txtString11 = " Pupil Tasks - Teaching and Core Learning Phase: " + shapesTxtv11.getText().toString();
        int a11=10, b11=1250;
        shapesPage.getCanvas().drawText(txtString11, a11, b11, mypaint);

        String txtString12 = " Pupil Tasks - Opening Phase: " + shapesTxtv12.getText().toString();
        int a12=10, b12=1450;
        shapesPage.getCanvas().drawText(txtString12, a12, b12, mypaint);

        String shapesString8 = "Any Changes to the Pupil Tasks: " + shapesEdtxt8.getText().toString();
        int x8=10, y8=1650;
        shapesPage.getCanvas().drawText(shapesString8, x8, y8, mypaint);

        String txtString13 = " Resources - Opening Phase: " + shapesTxtv13.getText().toString();
        int a13=10, b13=1750;
        shapesPage.getCanvas().drawText(txtString13, a13, b13, mypaint);

        String txtString14 = " Resources - Teaching and Core Learning Phase: " + shapesTxtv14.getText().toString();
        int a14=10, b14=1950;
        shapesPage.getCanvas().drawText(txtString14, a14, b14, mypaint);

        String txtString15 = " Resources - Opening Phase: " + shapesTxtv15.getText().toString();
        int a15=10, b15=2250;
        shapesPage.getCanvas().drawText(txtString15, a15, b15, mypaint);

        String shapesString9 = "Any Changes to the Resources: " + shapesEdtxt9.getText().toString();
        int x9=10, y9=2450;
        shapesPage.getCanvas().drawText(shapesString9, x9, y9, mypaint);

        String shapesString10 = "Evidence of Learning: " + shapesEdtxt10.getText().toString();
        int x10=10, y10=2650;
        shapesPage.getCanvas().drawText(shapesString10, x10, y10, mypaint);

        String shapesString11 = "Areas for Development: " + shapesEdtxt11.getText().toString();
        int x11=10, y11=2850;
        shapesPage.getCanvas().drawText(shapesString11, x11, y11, mypaint);

        String shapesString12 = "Evidence of Effective Practice: " + shapesEdtxt12.getText().toString();
        int x12=10, y12=3050;
        shapesPage.getCanvas().drawText(shapesString12, x12, y12, mypaint);

        String shapesString13 = "Areas for Development: " + shapesEdtxt13.getText().toString();
        int x13=10, y13=3250;
        shapesPage.getCanvas().drawText(shapesString13, x13, y13, mypaint);

        TextPaint textPaint = new TextPaint();

        //finish adding to pdf
        shapesPdfDocument.finishPage(shapesPage);


        //create path to access pdf
        String myFilePath = Environment.getExternalStorageDirectory().getPath() + "/ShapesLessonPlan.pdf";
        File myFile = new File(myFilePath);

        try {
            shapesPdfDocument.writeTo(new FileOutputStream(myFile));
        }
        catch (Exception e){

            e.printStackTrace();
            shapesEdtxt.setText("ERROR");

        }

        //close pdf object
        shapesPdfDocument.close();

        //show message that pdf is saved
        Toast.makeText(this, myFilePath + ".pdf\nis saved to\n", Toast.LENGTH_SHORT).show();
        
    }



    }