package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class HealthActivity extends AppCompatActivity {

    private static final String TAG = "HealthActivity";

    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health);
        ListView list = (ListView) findViewById(R.id.healthList);
        EditText healthFilter = (EditText) findViewById(R.id.searchFilterHealth);
        Log.d(TAG, "onCreate: Started.");

        ArrayList<String> healthLessons = new ArrayList<>();
        //add items to list of health lessons
        healthLessons.add("Feelings and Emotions - P2/3");
        healthLessons.add("Lesson 2");
        healthLessons.add("Lesson 3");
        healthLessons.add("Lesson 4");
        healthLessons.add("Lesson 5");
        healthLessons.add("Lesson 6");

        adapter = new ArrayAdapter(this, R.layout.list_item_layout, healthLessons);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //what to do if item is clicked that matches string
                if (((String)adapter.getItem(position)==("Feelings and Emotions - P2/3"))){
                    Intent myIntent = new Intent(view.getContext(),HealthLesson.class);
                    startActivityForResult(myIntent,0);
                }
            }
        });

        //filter listview
        healthFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (HealthActivity.this).adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
