package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
    }

    //Planner button
    public void planner_action(View view) {

        Intent plannerIntent = new Intent(MainPageActivity.this, PlannerActivity.class);
        MainPageActivity.this.startActivity(plannerIntent);
    }

    //create lesson plan button
    public void create_action(View view) {

        Intent createIntent = new Intent(MainPageActivity.this, CreateActivity.class);
        MainPageActivity.this.startActivity(createIntent);
    }

    //maths subject button
    public void maths_action(View view) {

        Intent mathsIntent = new Intent(MainPageActivity.this, MathsActivity.class);
        MainPageActivity.this.startActivity(mathsIntent);
    }

    //language subject button
    public void language_action(View view) {

        Intent languageIntent = new Intent(MainPageActivity.this, LanguageActivity.class);
        MainPageActivity.this.startActivity(languageIntent);
    }

    //science subject button
    public void science_action(View view) {

        Intent scienceIntent = new Intent(MainPageActivity.this, ScienceActivity.class);
        MainPageActivity.this.startActivity(scienceIntent);
    }

    //expressive arts subject button
    public void arts_action(View view) {

        Intent artsIntent = new Intent(MainPageActivity.this, ArtsActivity.class);
        MainPageActivity.this.startActivity(artsIntent);
    }

    //health and wellbeing subject button
    public void health_action(View view) {

        Intent healthIntent = new Intent(MainPageActivity.this, HealthActivity.class);
        MainPageActivity.this.startActivity(healthIntent);
    }

    //social sciences subject button
    public void social_action(View view) {

        Intent socialIntent = new Intent(MainPageActivity.this, SocialActivity.class);
        MainPageActivity.this.startActivity(socialIntent);
    }

    //technology subject button
    public void tech_action(View view) {

        Intent techIntent = new Intent(MainPageActivity.this, TechActivity.class);
        MainPageActivity.this.startActivity(techIntent);
    }

    //religious and moral education subject button
    public void re_action(View view) {

        Intent reIntent = new Intent(MainPageActivity.this, ReActivity.class);
        MainPageActivity.this.startActivity(reIntent);
    }

    //set learning goals button
    public void learning_goals_action(View view) {

        Intent learningGoalsIntent = new Intent(MainPageActivity.this, SetLearningGoals.class);
        MainPageActivity.this.startActivity(learningGoalsIntent);
    }

    //log out
    public void log_out_action(View view) {

        Intent logOutIntent = new Intent(MainPageActivity.this, MainActivity.class);
        MainPageActivity.this.startActivity(logOutIntent);
    }


}