package com.example.dissertationproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class HealthLesson extends AppCompatActivity {

    //declaring views
    private EditText feelEdtxt;
    private EditText feelEdtxt2;
    private TextView feelTxtv;
    private TextView feelTxtv2;
    private TextView feelTxtv3;
    private EditText feelEdtxt3;
    private TextView feelTxtv4;
    private EditText feelEdtxt4;
    private TextView feelTxtv5;
    private EditText feelEdtxt5;
    private TextView feelTxtv6;
    private EditText feelEdtxt6;
    private TextView feelTxtv7;
    private TextView feelTxtv8;
    private TextView feelTxtv9;
    private EditText feelEdtxt7;
    private TextView feelTxtv10;
    private TextView feelTxtv11;
    private TextView feelTxtv12;
    private EditText feelEdtxt8;
    private TextView feelTxtv13;
    private TextView feelTxtv14;
    private TextView feelTxtv15;
    private EditText feelEdtxt9;
    private EditText feelEdtxt10;
    private EditText feelEdtxt11;
    private EditText feelEdtxt12;
    private EditText feelEdtxt13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_lesson);

        //initialising views
        feelEdtxt = findViewById(R.id.studentFeel);
        feelTxtv = findViewById(R.id.p2_3Feel);
        feelEdtxt2 = findViewById(R.id.dateOfFeelLesson);
        feelTxtv2 = findViewById(R.id.feel);
        feelTxtv3 = findViewById(R.id.generatedEAndOFeel);
        feelEdtxt3 = findViewById(R.id.enterEAndOChangesFeel);
        feelTxtv4 = findViewById(R.id.generatedLIFeel);
        feelEdtxt4 = findViewById(R.id.enterLIChangesFeel);
        feelTxtv5 = findViewById(R.id.generatedSuccessCriteriaFeel);
        feelEdtxt5 = findViewById(R.id.enterSuccessCriteriaChangesFeel);
        feelTxtv6 = findViewById(R.id.generatedAssessmentLearningFeel);
        feelEdtxt6 = findViewById(R.id.enterAssessLearningChangesFeel);
        feelTxtv7 = findViewById(R.id.activitiesOpenFeel);
        feelTxtv8 = findViewById(R.id.activitiesCoreFeel);
        feelTxtv9 = findViewById(R.id.activitiesCloseFeel);
        feelEdtxt7 = findViewById(R.id.enterActivitiesChangesFeel);
        feelTxtv10 = findViewById(R.id.pupilOpenFeel);
        feelTxtv11 = findViewById(R.id.pupilCoreFeel);
        feelTxtv12 = findViewById(R.id.pupilCloseFeel);
        feelEdtxt8 = findViewById(R.id.enterPupilChangesFeel);
        feelTxtv13 = findViewById(R.id.resourcesOpenFeel);
        feelTxtv14 = findViewById(R.id.resourcesCoreFeel);
        feelTxtv15 = findViewById(R.id.resourcesCloseFeel);
        feelEdtxt9 = findViewById(R.id.enterResourcesChangesFeel);
        feelEdtxt10 = findViewById(R.id.evidenceLearningFeel);
        feelEdtxt11 = findViewById(R.id.areasDevelopFeel);
        feelEdtxt12 = findViewById(R.id.evidencePracticeFeel);
        feelEdtxt13 = findViewById(R.id.practiceAreasDevelopFeel);
        ActivityCompat.requestPermissions(HealthLesson.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createFeelPDF (View view){

        //create pdf object
        PdfDocument feelPdfDocument = new PdfDocument();
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        PdfDocument.Page feelPage = feelPdfDocument.startPage(myPageInfo);

        //add to pdf object
        Paint mypaint = new Paint();
        String feelString = "Student: "+ feelEdtxt.getText().toString();
        int x=10, y=25;
        feelPage.getCanvas().drawText(feelString, x, y, mypaint);

        String txtString = "Class: " + feelTxtv.getText().toString();
        int a=10, b=35;
        feelPage.getCanvas().drawText(txtString, a, b, mypaint);

        String feelString2 = "Date: " + feelEdtxt2.getText().toString();
        int x2=10, y2=45;
        feelPage.getCanvas().drawText(feelString2, x2, y2, mypaint);

        String txtString2 = "Lesson Title: " + feelTxtv2.getText().toString();
        int a2=10, b2=55;
        feelPage.getCanvas().drawText(txtString2, a2, b2, mypaint);

        String txtString3 = "Experiences and Outcomes: " + feelTxtv3.getText().toString();
        int a3=10, b3=105;
        feelPage.getCanvas().drawText(txtString3, a3, b3, mypaint);

        String feelString3 = "Any Changes to Experiences and Outcomes: " + feelEdtxt3.getText().toString();
        int x3=10, y3=200;
        feelPage.getCanvas().drawText(feelString3, x3, y3, mypaint);

        String txtString4 = "Learning Intentions: " + feelTxtv4.getText().toString();
        int a4=10, b4=250;
        feelPage.getCanvas().drawText(txtString4, a4, b4, mypaint);

        String feelString4 ="Any Changes to Learning Intentions: " + feelEdtxt4.getText().toString();
        int x4=10, y4= 350;
        feelPage.getCanvas().drawText(feelString4, x4, y4, mypaint);

        String txtString5 = "Success Criteria: " + feelTxtv5.getText().toString();
        int a5=10, b5=400;
        feelPage.getCanvas().drawText(txtString5, a5, b5, mypaint);

        String feelString5 = "Any Changes to Success Criteria: " + feelEdtxt5.getText().toString();
        int x5=10, y5=500;
        feelPage.getCanvas().drawText(feelString5, x5, y5, mypaint);

        String txtString6 = "Assessment of Children's Learning: " + feelTxtv6.getText().toString();
        int a6=10, b6=550;
        feelPage.getCanvas().drawText(txtString6, a6, b6, mypaint);

        String feelString6 = "Any Changes to Children's Learning: " + feelEdtxt6.getText().toString();
        int x6=10, y6=650;
        feelPage.getCanvas().drawText(feelString6, x6, y6, mypaint);

        String txtString7 = " Activities - Opening Phase: " + feelTxtv7.getText().toString();
        int a7=10, b7=700;
        feelPage.getCanvas().drawText(txtString7, a7, b7, mypaint);

        String txtString8 = " Activities - Teaching and Core Learning Phase: " + feelTxtv8.getText().toString();
        int a8=10, b8=800;
        feelPage.getCanvas().drawText(txtString8, a8, b8, mypaint);

        String txtString9 = " Activities - Opening Phase: " + feelTxtv9.getText().toString();
        int a9=10, b9=900;
        feelPage.getCanvas().drawText(txtString9, a9, b9, mypaint);

        String feelString7 = "Any Changes to the Activities: " + feelEdtxt7.getText().toString();
        int x7=10, y7=1000;
        feelPage.getCanvas().drawText(feelString7, x7, y7, mypaint);

        String txtString10 = " Pupil Tasks - Opening Phase: " + feelTxtv10.getText().toString();
        int a10=10, b10=1050;
        feelPage.getCanvas().drawText(txtString10, a10, b10, mypaint);

        String txtString11 = " Pupil Tasks - Teaching and Core Learning Phase: " + feelTxtv11.getText().toString();
        int a11=10, b11=1250;
        feelPage.getCanvas().drawText(txtString11, a11, b11, mypaint);

        String txtString12 = " Pupil Tasks - Opening Phase: " + feelTxtv12.getText().toString();
        int a12=10, b12=1450;
        feelPage.getCanvas().drawText(txtString12, a12, b12, mypaint);

        String feelString8 = "Any Changes to the Pupil Tasks: " + feelEdtxt8.getText().toString();
        int x8=10, y8=1650;
        feelPage.getCanvas().drawText(feelString8, x8, y8, mypaint);

        String txtString13 = " Resources - Opening Phase: " + feelTxtv13.getText().toString();
        int a13=10, b13=1750;
        feelPage.getCanvas().drawText(txtString13, a13, b13, mypaint);

        String txtString14 = " Resources - Teaching and Core Learning Phase: " + feelTxtv14.getText().toString();
        int a14=10, b14=1950;
        feelPage.getCanvas().drawText(txtString14, a14, b14, mypaint);

        String txtString15 = " Resources - Opening Phase: " + feelTxtv15.getText().toString();
        int a15=10, b15=2250;
        feelPage.getCanvas().drawText(txtString15, a15, b15, mypaint);

        String feelString9 = "Any Changes to the Resources: " + feelEdtxt9.getText().toString();
        int x9=10, y9=2450;
        feelPage.getCanvas().drawText(feelString9, x9, y9, mypaint);

        String feelString10 = "Evidence of Learning: " + feelEdtxt10.getText().toString();
        int x10=10, y10=2650;
        feelPage.getCanvas().drawText(feelString10, x10, y10, mypaint);

        String feelString11 = "Areas for Development: " + feelEdtxt11.getText().toString();
        int x11=10, y11=2850;
        feelPage.getCanvas().drawText(feelString11, x11, y11, mypaint);

        String feelString12 = "Evidence of Effective Practice: " + feelEdtxt12.getText().toString();
        int x12=10, y12=3050;
        feelPage.getCanvas().drawText(feelString12, x12, y12, mypaint);

        String feelString13 = "Areas for Development: " + feelEdtxt13.getText().toString();
        int x13=10, y13=3250;
        feelPage.getCanvas().drawText(feelString13, x13, y13, mypaint);

        //finish adding to pdf object
        feelPdfDocument.finishPage(feelPage);

        //create path to access pdf
        String myFilePath = Environment.getExternalStorageDirectory().getPath()+ "/Feelings_EmotionsLessonPlan.pdf";
        File myFile = new File(myFilePath);

        try {
            feelPdfDocument.writeTo(new FileOutputStream(myFile));
        }

        catch (Exception e) {

            e.printStackTrace();
            feelEdtxt.setText("Error");
        }

        //close pdf object
        feelPdfDocument.close();

        //show message that pdf has saved
        Toast.makeText(this, myFilePath + ".pdf\nis saved to\n", Toast.LENGTH_SHORT).show();
    }
}