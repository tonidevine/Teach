package com.example.dissertationproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class LanguageLesson extends AppCompatActivity {

    //declaring views
    private EditText novelEdtxt;
    private EditText novelEdtxt2;
    private TextView novelTxtv;
    private TextView novelTxtv2;
    private TextView novelTxtv3;
    private EditText novelEdtxt3;
    private TextView novelTxtv4;
    private EditText novelEdtxt4;
    private TextView novelTxtv5;
    private EditText novelEdtxt5;
    private TextView novelTxtv6;
    private EditText novelEdtxt6;
    private TextView novelTxtv7;
    private TextView novelTxtv8;
    private TextView novelTxtv9;
    private EditText novelEdtxt7;
    private TextView novelTxtv10;
    private TextView novelTxtv11;
    private TextView novelTxtv12;
    private EditText novelEdtxt8;
    private TextView novelTxtv13;
    private TextView novelTxtv14;
    private TextView novelTxtv15;
    private EditText novelEdtxt9;
    private EditText novelEdtxt10;
    private EditText novelEdtxt11;
    private EditText novelEdtxt12;
    private EditText novelEdtxt13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_lesson);

        //initialising views
        novelEdtxt = findViewById(R.id.studentNovel);
        novelTxtv = findViewById(R.id.p7Novel);
        novelEdtxt2 = findViewById(R.id.dateOfNovelLesson);
        novelTxtv2 = findViewById(R.id.novel);
        novelTxtv3 = findViewById(R.id.generatedEAndONovel);
        novelEdtxt3 = findViewById(R.id.enterEAndOChangesNovel);
        novelTxtv4 = findViewById(R.id.generatedLINovel);
        novelEdtxt4 = findViewById(R.id.enterLIChangesNovel);
        novelTxtv5 = findViewById(R.id.generatedSuccessCriteriaNovel);
        novelEdtxt5 = findViewById(R.id.enterSuccessCriteriaChangesNovel);
        novelTxtv6 = findViewById(R.id.generatedAssessmentLearningNovel);
        novelEdtxt6 = findViewById(R.id.enterAssessLearningChangesNovel);
        novelTxtv7 = findViewById(R.id.activitiesOpenNovel);
        novelTxtv8 = findViewById(R.id.activitiesCoreNovel);
        novelTxtv9 = findViewById(R.id.activitiesCloseNovel);
        novelEdtxt7 = findViewById(R.id.enterActivitiesChangesNovel);
        novelTxtv10 = findViewById(R.id.pupilOpenNovel);
        novelTxtv11 = findViewById(R.id.pupilCoreNovel);
        novelTxtv12 = findViewById(R.id.pupilCloseNovel);
        novelEdtxt8 = findViewById(R.id.enterPupilChangesNovel);
        novelTxtv13 = findViewById(R.id.resourcesOpenNovel);
        novelTxtv14 = findViewById(R.id.resourcesCoreNovel);
        novelTxtv15 = findViewById(R.id.resourcesCloseNovel);
        novelEdtxt9 = findViewById(R.id.enterResourcesChangesNovel);
        novelEdtxt10 = findViewById(R.id.evidenceLearningNovel);
        novelEdtxt11 = findViewById(R.id.areasDevelopNovel);
        novelEdtxt12 = findViewById(R.id.evidencePracticeNovel);
        novelEdtxt13 = findViewById(R.id.practiceAreasDevelopNovel);
        ActivityCompat.requestPermissions(LanguageLesson.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);

    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createNovelPDF (View view){

        //create pdf object
        PdfDocument novelPdfDocument = new PdfDocument();
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        PdfDocument.Page novelPage = novelPdfDocument.startPage(myPageInfo);

        //add to pdf object
        Paint mypaint = new Paint();
        String novelString = "Student: "+ novelEdtxt.getText().toString();
        int x=10, y=25;
        novelPage.getCanvas().drawText(novelString, x, y, mypaint);

        String txtString = "Class: " + novelTxtv.getText().toString();
        int a=10, b=35;
        novelPage.getCanvas().drawText(txtString, a, b, mypaint);

        String novelString2 = "Date: " + novelEdtxt2.getText().toString();
        int x2=10, y2=45;
        novelPage.getCanvas().drawText(novelString2, x2, y2, mypaint);

        String txtString2 = "Lesson Title: " + novelTxtv2.getText().toString();
        int a2=10, b2=55;
        novelPage.getCanvas().drawText(txtString2, a2, b2, mypaint);

        String txtString3 = "Experiences and Outcomes: " + novelTxtv3.getText().toString();
        int a3=10, b3=105;
        novelPage.getCanvas().drawText(txtString3, a3, b3, mypaint);

        String novelString3 = "Any Changes to Experiences and Outcomes: " + novelEdtxt3.getText().toString();
        int x3=10, y3=200;
        novelPage.getCanvas().drawText(novelString3, x3, y3, mypaint);

        String txtString4 = "Learning Intentions: " + novelTxtv4.getText().toString();
        int a4=10, b4=250;
        novelPage.getCanvas().drawText(txtString4, a4, b4, mypaint);

        String novelString4 ="Any Changes to Learning Intentions: " + novelEdtxt4.getText().toString();
        int x4=10, y4= 350;
        novelPage.getCanvas().drawText(novelString4, x4, y4, mypaint);

        String txtString5 = "Success Criteria: " + novelTxtv5.getText().toString();
        int a5=10, b5=400;
        novelPage.getCanvas().drawText(txtString5, a5, b5, mypaint);

        String novelString5 = "Any Changes to Success Criteria: " + novelEdtxt5.getText().toString();
        int x5=10, y5=500;
        novelPage.getCanvas().drawText(novelString5, x5, y5, mypaint);

        String txtString6 = "Assessment of Children's Learning: " + novelTxtv6.getText().toString();
        int a6=10, b6=550;
        novelPage.getCanvas().drawText(txtString6, a6, b6, mypaint);

        String novelString6 = "Any Changes to Children's Learning: " + novelEdtxt6.getText().toString();
        int x6=10, y6=650;
        novelPage.getCanvas().drawText(novelString6, x6, y6, mypaint);

        String txtString7 = " Activities - Opening Phase: " + novelTxtv7.getText().toString();
        int a7=10, b7=700;
        novelPage.getCanvas().drawText(txtString7, a7, b7, mypaint);

        String txtString8 = " Activities - Teaching and Core Learning Phase: " + novelTxtv8.getText().toString();
        int a8=10, b8=800;
        novelPage.getCanvas().drawText(txtString8, a8, b8, mypaint);

        String txtString9 = " Activities - Opening Phase: " + novelTxtv9.getText().toString();
        int a9=10, b9=900;
        novelPage.getCanvas().drawText(txtString9, a9, b9, mypaint);

        String novelString7 = "Any Changes to the Activities: " + novelEdtxt7.getText().toString();
        int x7=10, y7=1000;
        novelPage.getCanvas().drawText(novelString7, x7, y7, mypaint);

        String txtString10 = " Pupil Tasks - Opening Phase: " + novelTxtv10.getText().toString();
        int a10=10, b10=1050;
        novelPage.getCanvas().drawText(txtString10, a10, b10, mypaint);

        String txtString11 = " Pupil Tasks - Teaching and Core Learning Phase: " + novelTxtv11.getText().toString();
        int a11=10, b11=1250;
        novelPage.getCanvas().drawText(txtString11, a11, b11, mypaint);

        String txtString12 = " Pupil Tasks - Opening Phase: " + novelTxtv12.getText().toString();
        int a12=10, b12=1450;
        novelPage.getCanvas().drawText(txtString12, a12, b12, mypaint);

        String novelString8 = "Any Changes to the Pupil Tasks: " + novelEdtxt8.getText().toString();
        int x8=10, y8=1650;
        novelPage.getCanvas().drawText(novelString8, x8, y8, mypaint);

        String txtString13 = " Resources - Opening Phase: " + novelTxtv13.getText().toString();
        int a13=10, b13=1750;
        novelPage.getCanvas().drawText(txtString13, a13, b13, mypaint);

        String txtString14 = " Resources - Teaching and Core Learning Phase: " + novelTxtv14.getText().toString();
        int a14=10, b14=1950;
        novelPage.getCanvas().drawText(txtString14, a14, b14, mypaint);

        String txtString15 = " Resources - Opening Phase: " + novelTxtv15.getText().toString();
        int a15=10, b15=2250;
        novelPage.getCanvas().drawText(txtString15, a15, b15, mypaint);

        String novelString9 = "Any Changes to the Resources: " + novelEdtxt9.getText().toString();
        int x9=10, y9=2450;
        novelPage.getCanvas().drawText(novelString9, x9, y9, mypaint);

        String novelString10 = "Evidence of Learning: " + novelEdtxt10.getText().toString();
        int x10=10, y10=2650;
        novelPage.getCanvas().drawText(novelString10, x10, y10, mypaint);

        String novelString11 = "Areas for Development: " + novelEdtxt11.getText().toString();
        int x11=10, y11=2850;
        novelPage.getCanvas().drawText(novelString11, x11, y11, mypaint);

        String novelString12 = "Evidence of Effective Practice: " + novelEdtxt12.getText().toString();
        int x12=10, y12=3050;
        novelPage.getCanvas().drawText(novelString12, x12, y12, mypaint);

        String novelString13 = "Areas for Development: " + novelEdtxt13.getText().toString();
        int x13=10, y13=3250;
        novelPage.getCanvas().drawText(novelString13, x13, y13, mypaint);

        //finish adding to pdf object
        novelPdfDocument.finishPage(novelPage);

        //create path to access pdf
        String myFilePath = Environment.getExternalStorageDirectory().getPath()+ "/NovelLessonPlan.pdf";
        File myFile = new File(myFilePath);

        try {
            novelPdfDocument.writeTo(new FileOutputStream(myFile));
        }

        catch (Exception e) {

            e.printStackTrace();
            novelEdtxt.setText("Error");
        }

        //close pdf object
        novelPdfDocument.close();

        //show message that pdf is saved
        Toast.makeText(this, myFilePath + ".pdf\nis saved to\n", Toast.LENGTH_SHORT).show();
    }
}