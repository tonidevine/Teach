package com.example.dissertationproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapter extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapter(Context context) {
        this.context = context;
    }

    int images[] = {

            R.drawable.create,
            R.drawable.calendar,
            R.drawable.set_learning_goals,
            R.drawable.maths,
            R.drawable.maths_list_lessons,
            R.drawable.maths_plan,
            R.drawable.ready_to_learn
    };

    int headings[] = {

            R.string.create_lesson_title,
            R.string.planner_title,
            R.string.todolist_title,
            R.string.select_subject_title,
            R.string.filter_search,
            R.string.lesson_plan_changes,
            R.string.ready_to_learn_title

    };

    int descriptions[] = {

            R.string.create_lesson_description,
            R.string.planner_description,
            R.string.todolist_description,
            R.string.select_subject_description,
            R.string.filter_search_description,
            R.string.lesson_plan_changes_description,
            R.string.ready_to_learn_url
    };

    @Override
    public int getCount() {
        return headings.length;
    }

    //set the view
    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (ConstraintLayout) object;
    }


    //change item for each slide
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slides_layout,container,false);

        ImageView imageView = view.findViewById(R.id.slider_image);
        TextView heading = view.findViewById(R.id.slider_heading);
        TextView desc = view.findViewById(R.id.slider_desc);

        imageView.setImageResource(images[position]);
        heading.setText(headings[position]);
        desc.setText(descriptions[position]);

        container.addView(view);

        return view;
    }

    //destroyed that
    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((ConstraintLayout)object);
    }
}


