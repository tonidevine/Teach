package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MathsActivity extends AppCompatActivity {

    private static final String TAG = "MathsActivity";

    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths);
        ListView list = (ListView) findViewById(R.id.mathsList);
        EditText mathsFilter = (EditText) findViewById(R.id.searchFilter);
        Log.d(TAG, "onCreate: Started.");

        final ArrayList<String> mathsLessons = new ArrayList<>();
        //add items to list of maths lessons
        mathsLessons.add("Shapes Lesson - Primary 2/3");
        mathsLessons.add("Lesson 2");
        mathsLessons.add("Lesson 3");
        mathsLessons.add("Lesson 4");
        mathsLessons.add("Lesson 5");
        mathsLessons.add("Lesson 6");

        adapter = new ArrayAdapter(this, R.layout.list_item_layout, mathsLessons);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //what to do if item is clicked that matches string
                if (((String)adapter.getItem(position)==("Shapes Lesson - Primary 2/3"))){
                    Intent myIntent = new Intent(view.getContext(),MathsLesson.class);
                    startActivityForResult(myIntent,0);
                }

            }
        });

        //filter listview
        mathsFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (MathsActivity.this).adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }
}
