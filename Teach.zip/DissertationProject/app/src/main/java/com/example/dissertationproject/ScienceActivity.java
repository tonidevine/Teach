package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class ScienceActivity extends AppCompatActivity {

    private static final String TAG = "ScienceActivity";

    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science);
        ListView list = (ListView) findViewById(R.id.scienceList);
        EditText scienceFilter = (EditText) findViewById(R.id.searchFilterScience);
        Log.d(TAG, "onCreate: Started.");

        ArrayList<String> scienceLessons = new ArrayList<>();
        //add items to list of science lessons
        scienceLessons.add("Lesson 1");
        scienceLessons.add("Lesson 2");
        scienceLessons.add("Lesson 3");
        scienceLessons.add("Lesson 4");
        scienceLessons.add("Lesson 5");
        scienceLessons.add("Lesson 6");

         adapter = new ArrayAdapter(this, R.layout.list_item_layout, scienceLessons);
        list.setAdapter(adapter);


        //filter listview
        scienceFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (ScienceActivity.this).adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
