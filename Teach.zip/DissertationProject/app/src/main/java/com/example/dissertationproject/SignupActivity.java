package com.example.dissertationproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;

import android.widget.EditText;
import android.widget.ImageView;



public class SignupActivity extends AppCompatActivity {

//declare
    private String[] emailAddresses;
    private EditText pass1;
    private EditText pass2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //intialise
        pass1 = findViewById(R.id.passwordInput);
        pass2 = findViewById(R.id.passwordConfirm);


        ImageView passToggle = findViewById(R.id.passVisibleToggle);

        //show password
        passToggle.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        pass1.setInputType(InputType.TYPE_CLASS_TEXT);
                        pass2.setInputType(InputType.TYPE_CLASS_TEXT);
                        break;
                    case MotionEvent.ACTION_UP:
                        pass1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        pass2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        break;
                }
                return true;
            }
        });
    }

    //open app once sign up is valid
    public void signupButton(View view) {

        if (isEmailValid() && doPasswordsMatch() && isEmailAvailable() ) {
            Intent loginIntent = new Intent(SignupActivity.this, MainPageActivity.class);
            SignupActivity.this.startActivity(loginIntent);
        }

    }

    //check if email used to sign up is valid
    public boolean isEmailValid() {

        EditText inputView = findViewById(R.id.emailInput);
        String inputEmail = inputView.getText().toString();
        int emailLength = inputEmail.length();


        if (emailLength > 5 && inputEmail.contains("@") && inputEmail.contains(".")) {
            return true;
        }

        else {
            inputView.startAnimation(shakeError());
            inputView.setError("Please input a valid email address");
            return false;
        }

    }


    //check that passwords entered match
    public boolean doPasswordsMatch() {

        pass1 = findViewById(R.id.passwordInput);
        pass2 = findViewById(R.id.passwordConfirm);

        String pass1Text = pass1.getText().toString();
        String pass2Text = pass2.getText().toString();

        if (pass1Text.equals(pass2Text) && !pass1Text.equals("")) {
            return true;
        }

        pass1.startAnimation(shakeError());
        pass2.startAnimation(shakeError());
        pass1.setError("Passwords do not match");
        pass2.setError("Passwords do not match");
        return false;

    }



    public boolean isEmailAvailable() {

        EditText inputView = findViewById(R.id.emailInput);
        String inputEmail = inputView.getText().toString();

        emailAddresses = this.getResources().getStringArray(R.array.emailAddresses);

        for (String email : emailAddresses) {

            if (inputEmail.equals(email)) {

                inputView.startAnimation(shakeError());
                inputView.setError("This email has already been used!");
                return false;

            }
        }

        return true;

    }

    public TranslateAnimation shakeError() {
        TranslateAnimation shake = new TranslateAnimation(0, 8, 0, 0);
        shake.setDuration(400);
        shake.setInterpolator(new CycleInterpolator(5));
        return shake;
    }
}
