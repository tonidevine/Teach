package com.example.dissertationproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;

public class PlannerActivity extends AppCompatActivity {

    private static final String TAG = "PlannerActivity";

    private CalendarView mCalendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planner);

        //planner
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);

    }
}
