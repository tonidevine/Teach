package com.example.dissertationproject;


import android.Manifest;

import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;

import android.widget.EditText;
import android.widget.Toast;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;

import java.io.FileOutputStream;



public class CreateActivity extends AppCompatActivity {

    //declaring views
    private EditText mTxtEt;
    private EditText mTxtEt2;
    private EditText mTxtEt3;
    private EditText mTxtEt4;
    private EditText mTxtEt5;
    private EditText mTxtEt6;
    private EditText mTxtEt7;
    private EditText mTxtEt8;
    private EditText mTxtEt9;
    private EditText mTxtEt10;
    private EditText mTxtEt11;
    private EditText mTxtEt12;
    private EditText mTxtEt13;
    private EditText mTxtEt14;
    private EditText mTxtEt15;
    private EditText mTxtEt16;
    private EditText mTxtEt17;
    private EditText mTxtEt18;
    private EditText mTxtEt19;
    private EditText mTxtEt20;
    private EditText mTxtEt21;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        //initialising views
        mTxtEt = findViewById(R.id.student);
        mTxtEt2 = findViewById(R.id.classOfLesson);
        mTxtEt3 = findViewById(R.id.dateOfLesson);
        mTxtEt4 = findViewById(R.id.titleOfLesson);
        mTxtEt5 = findViewById(R.id.enterEAndO);
        mTxtEt6 = findViewById(R.id.enterLI);
        mTxtEt7 = findViewById(R.id.enterSuccessCriteria);
        mTxtEt8 = findViewById(R.id.enterAssessmentLearning);
        mTxtEt9 = findViewById(R.id.activitiesOpen);
        mTxtEt10 = findViewById(R.id.activitiesCore);
        mTxtEt11 = findViewById(R.id.activitiesClose);
        mTxtEt12 = findViewById(R.id.pupilOpen);
        mTxtEt13 = findViewById(R.id.pupilCore);
        mTxtEt14 = findViewById(R.id.pupilClose);
        mTxtEt15 = findViewById(R.id.resourcesOpen);
        mTxtEt16 = findViewById(R.id.resourcesCore);
        mTxtEt17 = findViewById(R.id.resourcesClose);
        mTxtEt18 = findViewById(R.id.evidenceLearning);
        mTxtEt19 = findViewById(R.id.areasDevelop);
        mTxtEt20 = findViewById(R.id.evidencePractice);
        mTxtEt21 = findViewById(R.id.practiceAreasDevelop);
        ActivityCompat.requestPermissions(CreateActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createLessonPDF (View view){

        //create pdf object
        PdfDocument createLessonPdfDocument = new PdfDocument();
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(300, 1000, 1).create();
        PdfDocument.Page createLessonPage = createLessonPdfDocument.startPage(myPageInfo);

        //add to pdf object
        Paint mypaint = new Paint();
        String createString = "Student: "+ mTxtEt.getText().toString();
        int x=10, y=25;
        createLessonPage.getCanvas().drawText(createString, x, y, mypaint);

        String createString2 = "Class: "+ mTxtEt2.getText().toString();
        int x2=10, y2=45;
        createLessonPage.getCanvas().drawText(createString2, x2, y2, mypaint);

        String createString3 = "Date: "+ mTxtEt3.getText().toString();
        int x3=10, y3=65;
        createLessonPage.getCanvas().drawText(createString3, x3, y3, mypaint);

        String createString4 = "Title of Lesson: "+ mTxtEt4.getText().toString();
        int x4=10, y4=85;
        createLessonPage.getCanvas().drawText(createString4, x4, y4, mypaint);

        String createString5 = "Experiences and Outcomes: "+ mTxtEt5.getText().toString();
        int x5=10, y5=105;
        createLessonPage.getCanvas().drawText(createString5, x5, y5, mypaint);

        String createString6 = "Learning Intentions: "+ mTxtEt6.getText().toString();
        int x6=10, y6=150;
        createLessonPage.getCanvas().drawText(createString6, x6, y6, mypaint);

        String createString7 = "Success Criteria: "+ mTxtEt7.getText().toString();
        int x7=10, y7=200;
        createLessonPage.getCanvas().drawText(createString7, x7, y7, mypaint);

        String createString8 = "Assessment of Children's Learning: "+ mTxtEt8.getText().toString();
        int x8=10, y8=250;
        createLessonPage.getCanvas().drawText(createString8, x8, y8, mypaint);

        String createString9 = "Activities - Opening Phase: "+ mTxtEt9.getText().toString();
        int x9=10, y9=300;
        createLessonPage.getCanvas().drawText(createString9, x9, y9, mypaint);

        String createString10 = "Activities - Teaching and Core Learning Phase: "+ mTxtEt10.getText().toString();
        int x10=10, y10=350;
        createLessonPage.getCanvas().drawText(createString10, x10, y10, mypaint);

        String createString11 = "Activities - Closing Phase: "+ mTxtEt11.getText().toString();
        int x11=10, y11=400;
        createLessonPage.getCanvas().drawText(createString11, x11, y11, mypaint);

        String createString12 = "Pupil Tasks - Opening Phase: "+ mTxtEt12.getText().toString();
        int x12=10, y12=450;
        createLessonPage.getCanvas().drawText(createString12, x12, y12, mypaint);

        String createString13 = "Pupil Tasks - Teaching and Core Learning Phase: "+ mTxtEt13.getText().toString();
        int x13=10, y13=500;
        createLessonPage.getCanvas().drawText(createString13, x13, y13, mypaint);

        String createString14 = "Pupil Tasks - Closing Phase: "+ mTxtEt14.getText().toString();
        int x14=10, y14=550;
        createLessonPage.getCanvas().drawText(createString14, x14, y14, mypaint);

        String createString15 = "Resources - Opening Phase: "+ mTxtEt15.getText().toString();
        int x15=10, y15=600;
        createLessonPage.getCanvas().drawText(createString15, x15, y15, mypaint);

        String createString16 = "Resources - Teaching and Core Learning Phase: "+ mTxtEt16.getText().toString();
        int x16=10, y16=650;
        createLessonPage.getCanvas().drawText(createString16, x16, y16, mypaint);

        String createString17 = "Resources - Closing Phase: "+ mTxtEt17.getText().toString();
        int x17=10, y17=700;
        createLessonPage.getCanvas().drawText(createString17, x17, y17, mypaint);

        String createString18 = "Evaluation of Pupil Learning - Evidence of Learning: "+ mTxtEt18.getText().toString();
        int x18=10, y18=750;
        createLessonPage.getCanvas().drawText(createString18, x18, y18, mypaint);

        String createString19 = "Evaluation of Pupil Learning - Areas for Development: "+ mTxtEt19.getText().toString();
        int x19=10, y19=800;
        createLessonPage.getCanvas().drawText(createString19, x19, y19, mypaint);

        String createString20 = "Reflective Analysis of Teaching and Strategies for Development - Evidence of Effective Practice: "+ mTxtEt20.getText().toString();
        int x20=10, y20=850;
        createLessonPage.getCanvas().drawText(createString20, x20, y20, mypaint);

        String createString21 = "Reflective Analysis of Teaching and Strategies for Development - Areas for Development: "+ mTxtEt21.getText().toString();
        int x21=10, y21=900;
        createLessonPage.getCanvas().drawText(createString21, x21, y21, mypaint);


        //finish adding to pdf object
        createLessonPdfDocument.finishPage(createLessonPage);

        //create path to access pdf
        String myFilePath = Environment.getExternalStorageDirectory().getPath() + "/CreateLessonPlan.pdf";
        File myFile = new File(myFilePath);

        try {
            createLessonPdfDocument.writeTo(new FileOutputStream(myFile));
        }

        catch (Exception e){
            e.printStackTrace();
            mTxtEt.setText("Error");

        }

        //close pdf object
        createLessonPdfDocument.close();

        //show message that pdf has saved
        Toast.makeText(this, myFilePath + ".pdf\nis saved to\n", Toast.LENGTH_SHORT).show();
    }
}


